let express = require('express');
let app = express();
require('dotenv').config();


app.get("/", function(req, res){
  res.sendfile(__dirname + "/views/index.html")
})

app.use("/public", express.static(__dirname + "/public"))

app.get("/json", function(req, res){
  res.json(
    {"message": "Hello json"}
  );
});

app.get("/json", function(req, res){
  res.json({"message": "Hello json again"})
})


  

//app.get("/", function(req, res){
  //res.send("Hello Express");
//}) 





//console.log("Hello World")




































 module.exports = app;
